<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Tables</h1>
    <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official DataTables documentation</a>.</p>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
      <div class="card-header py-3 align-items-center">
        <h2 class="m-0 font-weight-bold text-primary">Liste des utilisateurs (<?php echo e($users->count()); ?>)</h2>
        <div class="text-right">
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary btn-icon-split">
                <span class="icon text-white-50">
                    <i class="fas fa-plus"></i>
                </span>
                <span class="text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Ajouter user</font></font></span>
            </a>
        </div>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th class="text-center">Num</th>
                    <th class="text-center">Nom</th>
                    <th class="text-center">Pseudo</th>
                    <th class="text-center">Email</th>
                    <th class="text-center">Role</th>
                    <th class="text-center">Date postée </th>
                    <th class="text-center">Etat</th>
                    <th class="text-center">Options</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th class="text-center">Num</th>
                    <th class="text-center">Nom</th>
                    <th class="text-center">Pseudo</th>
                    <th class="text-center">Email</th>
                    <th class="text-center">Role</th>
                    <th class="text-center">Date postée </th>
                    <th class="text-center">Statut</th>
                    <th class="text-center">Options</th>
                </tr>
            </tfoot>
            <tbody>
                <?php
                $rl=Auth::user()->role==4;
            ?>
              <?php ($nombre=0); ?>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e(++$nombre); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->pseudo); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <?php
                        if($user->role==4){
                           echo "Super Admin" ;
                        }elseif ($user->role==3) {
                          echo "Administrateur";
                        }elseif ($user->role==2) {
                          echo "Editeur(trice)";
                        } elseif($user->role==1){

                        }elseif ($user->role==0) {
                            echo "Utilisateur" ;
                        }
                    ?>
                </td>
                <td><?php echo e($user->created_at); ?></td>
                <td class="text-cenetr justify-content-center align-items-center">

                    <?php if ($user->etat==0): ?>
                       <button class="btn btn-warning btn-sm">Désactivé</button>
                    <?php else : ?>
                       <button class="btn btn-success btn-sm">Actif</button>
                    <?php endif ?>
                </td>
                
                <td class="text-center">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', App\UserPost::class)): ?>
                    <?php if (Auth::user()->id == $user->id): ?>
                     <a href='<?php echo e(route('profile.edit', $user->id)); ?>'
                         class='btn btn-info  btn-sm btn-circle'>
                        <i class='fas fa-edit'></i>
                     </a>
                    <?php else: ?>
                      <a href='<?php echo e(route('users.edit', $user->id)); ?>'
                        class='btn btn-info  btn-sm btn-circle'>
                            <i class='fas fa-edit'></i>
                      </a>
                    <?php endif ?>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', App\UserPost::class)): ?>
                     <?php if(Auth::user()->id != $user->id): ?>
                     

                    <form onclick="return confirm('Etes-vous sure de vouloir supprimer cet article')" action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" style="display: inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class=" btn btn-sm btn-circle btn-danger my-4"><i class="fas fa-trash"></i></button>
                    </form>
                     <?php endif; ?>
                    <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <script>
      $(".btndel").on('click', function(e){
          e.preventDefault();
           $action = $(this).attr('action')
            Swal.fire({
            title: 'Etes vous sûre?',
            text: "Vous êtes sur le point de supprimer cet utilisateur !",
            icon: 'question',
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            cancelButtonText: 'Annuler',
            confirmButtonText: 'Oui, Supprimer!'
            }).then((result) => {
            if (result.value) {
               document.location.href = $action;
            }
            })
      })
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/users/index.blade.php ENDPATH**/ ?>