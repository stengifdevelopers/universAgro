                <?php echo csrf_field(); ?>
                <div class="form-group">
                <label for="titre">Titre de l'annonce <span class="font-weight-bold" style="color: red">*</span></label>
                <input id="titre" class="form-control form-control-md <?php if ($errors->has('titre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('titre'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="titre"
                type="text" placeholder="Insérer un titre" value="<?php echo e(isset ($annonce) ?  $annonce->titre : old('titre')); ?> ">
                <?php if ($errors->has('titre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('titre'); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                <label for="exampleFormControlTextarea3">Description de l'annonce <span class="font-weight-bold" style="color: red">*</span></label>
                <textarea name="contenu" class="form-control text-justify <?php if ($errors->has('contenu')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contenu'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="exampleFormControlTextarea3" placeholder="Insérer un contenu" rows="7"><?php echo isset ($annonce) ?  $annonce->contenu : old('contenu'); ?></textarea>
                <?php if ($errors->has('contenu')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contenu'); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="choix[]" value="1"  class="custom-control-input" id="defaultUnchecked" onclick="myFunction2()" <?php if(is_array(old('choix')) && in_array(1, old('choix'))): ?> checked <?php endif; ?>>
                    <label class="custom-control-label" for="defaultUnchecked">Location / Vente de terrain</label> <br>
                    <small class="text-muted">Si l'annonce concerne une vente ou une location de terrain, cochez l'option <span style="color: rgb(13, 236, 24)">Location / Vente de terrain</span></small>
                </div>
                <div class="row mt-4" id="text" style="visibility:hidden;height:0px;">
                    <div class="col-lg-5">
                        <div class="form-group">
                            <label for="localisation">Localisation <span class="font-weight-bold" style="color: red">*</span></label>
                            <input id="localisation" class="form-control form-control-md <?php if ($errors->has('localisation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('localisation'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="localisation"
                            type="text" value="<?php echo e(isset ($annonce) ?  $annonce->localisation : old('localisation')); ?> ">
                            <?php if ($errors->has('localisation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('localisation'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label for="superficie">Superficie <span class="font-weight-bold" style="color: red">*</span></label>
                            <input id="superficie" class="form-control form-control-md <?php if ($errors->has('superficie')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('superficie'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="superficie"
                            type="text" value="<?php echo e(isset ($annonce) ?  $annonce->superficie : old('superficie')); ?> ">
                            <?php if ($errors->has('superficie')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('superficie'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label for="price">Price <span class="font-weight-bold" style="color: red">*</span></label>
                            <input id="price" min="1" class="form-control form-control-md <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="price"
                            type="number" value="<?php echo e(isset ($annonce) ?  $annonce->price : old('price')); ?> ">
                            <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    
                </div>
                <div class="row" id="emailFirst">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="source">Source</label>
                            <input id="source" class="form-control form-control-md <?php if ($errors->has('source')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('source'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="source"
                            type="text" value="<?php echo e(isset ($annonce) ?  $annonce->source : old('source')); ?> ">
                            <?php if ($errors->has('source')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('source'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="editeur">Editeur</label>
                            <input id="editeur" class="form-control form-control-md <?php if ($errors->has('editeur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editeur'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="editeur"
                            type="text" value="<?php echo e(isset ($annonce) ?  $annonce->editeur : old('editeur')); ?> ">
                            <?php if ($errors->has('editeur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editeur'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                    <label class="mt-3" for="">Fichier <span class="font-weight-bold" style="color: red">*</span></label>
                        <div class="form-group input-group ">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                            </div>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input <?php if ($errors->has('fichier')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fichier'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="fichier" value="<?php echo e(isset ($annonce) ?  $annonce->fichier : (old('fichier'))); ?>" id="inputGroupFile01 "  aria-describedby="">
                                <label class="custom-file-label " for="inputGroupFile01"><?php echo e((old('fichier'))); ?></label>
                            </div>
                            <?php if ($errors->has('fichier')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fichier'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    
                </div>
                <script>
                    // Material Select Initialization
                      $(document).ready(function() {
                      $('.mdb-select').materialSelect();
                      });
                  </script>
<?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/annonces/form.blade.php ENDPATH**/ ?>