<?php $__env->startSection('content'); ?>



    <div class="container">
            <!-- Outer Row -->
            <div class="row justify-content-center">

              <div class="col-xl-12 col-lg-12 col-md-12">

                <div class="card o-hidden border-0 shadow-lg my-5">
                  <div class="card-body p-5">
                    <!-- Nested Row within Card Body -->
                    <h1>Formulaire d'Ajout d'un article</h1>
                    <div class="text-right">
                        <a href="<?php echo e(route('articles.index')); ?>"><button class=" btn btn-sm btn-primary">Liste des Articles</button></a>
                    </div>
                    <form action="<?php echo e(route('articles.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo $__env->make('Admin.articles.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="text-center mt-5">
                            <button class="btn btn-sm btn-success">
                                Valider
                            </button>
                        </div>
                    </form>
                  </div>
                </div>

              </div>

            </div>

          </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/articles/create.blade.php ENDPATH**/ ?>