<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 mt-5">
            
            <div class="card">
                <div class="card-header">
                    <div class="text-center">
                        <img src="<?php echo e(asset('img/Logo_header.png')); ?>" class="img-fluid rounded-circe">
                    </div>
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('inscription.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                               <div class="form-group">
                                    <label for="nom" class="col-form-label text-md-right"><?php echo e(__('Nom')); ?></label>
                                    <input id="nom" type="text" class="form-control <?php if ($errors->has('nom')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nom'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nom" value="<?php echo e(old('nom')); ?>"  autocomplete="nom" autofocus>

                                    <?php if ($errors->has('nom')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nom'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                    <div class="form-group">
                                         <label for="pseudo" class="col-form-label text-md-right"><?php echo e(__('Pseudo')); ?></label>
                                         <input id="pseudo" type="text" class="form-control <?php if ($errors->has('pseudo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pseudo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="pseudo" value="<?php echo e(old('pseudo')); ?>"  autocomplete="pseudo" autofocus>

                                         <?php if ($errors->has('pseudo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pseudo'); ?>
                                             <span class="invalid-feedback" role="alert">
                                                 <strong><?php echo e($message); ?></strong>
                                             </span>
                                         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                     </div>
                             </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                              <div class="form-group">
                                   <label for="pwd" class="col-form-label text-md-right"><?php echo e(__('Mot de passe')); ?></label>
                                   <input id="pwd" type="password" class="form-control <?php if ($errors->has('pwd')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pwd'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="pwd" value="<?php echo e(old('pwd')); ?>"  autocomplete="pwd" autofocus>

                                   <?php if ($errors->has('pwd')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pwd'); ?>
                                       <span class="invalid-feedback" role="alert">
                                           <strong><?php echo e($message); ?></strong>
                                       </span>
                                   <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                               </div>
                            </div>
                            <div class="col-lg-6">
                               <div class="form-group">
                                   <label for="pwdC" class="col-form-label text-md-right"><?php echo e(__('Confirmer mot de passe')); ?></label>
                                   <input id="pwdC" type="password" class="form-control <?php if ($errors->has('pwdC')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pwdC'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="pwd_confirmation" autocomplete="pwd" autofocus>

                                   <?php if ($errors->has('pwdC')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pwdC'); ?>
                                       <span class="invalid-feedback" role="alert">
                                           <strong><?php echo e($message); ?></strong>
                                       </span>
                                   <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                               </div>
                            </div>
                          </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="email" class="col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
                                    <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>"  autocomplete="email" autofocus>

                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                        <label for="fonction" class="col-form-label text-md-right"><?php echo e(__('Profession')); ?></label>
                                        <input id="fonction" type="text" class="form-control <?php if ($errors->has('fonction')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fonction'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="fonction" value="<?php echo e(old('fonction')); ?>"  autocomplete="fonction" autofocus>

                                        <?php if ($errors->has('fonction')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fonction'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                        </div>
                    
                        <div class="form-group row">
                          
                        </div>
                        <p class="text-center text-default">Après la création de votre compte, veuillez completer votre profil  !!</p>  
                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-warning">
                                    <?php echo e(__('S\'inscrire')); ?>

                                </button>
                                    <a class="bt btn-link" href="<?php echo e(route('blogs.index')); ?>">
                                        <?php echo e(__('Déja inscrit? Créer mon blog')); ?>

                                    </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/auth/inscription.blade.php ENDPATH**/ ?>