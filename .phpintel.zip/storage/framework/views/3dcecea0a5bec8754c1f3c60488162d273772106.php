<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-12 col-lg-12 col-md-12">
              <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-5">
                <h1>Formulaire d'Ajout d'une annonce</h1>
                <div class="text-right">
                    <a href="<?php echo e(route('projets.index')); ?>"><button class=" btn btn-sm btn-primary">Consulter les projets</button></a>
                </div>
                    <form action="<?php echo e(route('projet.fichiers.store', $projet->id)); ?>" method="POST" enctype="multipart/form-data">
                                 <?php echo $__env->make('Admin.fichiers.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="text-center mt-5">
                                <button class="btn btn-success">Enregistrer</button>
                            </div>
                    </form>
                </div>
              </div>
            </div>
        </div>
        <div class="card mb-5">
        <p class="text-center h3 pt-5">Liste des fichiers du projet <span class="font-weight-bold text-success">"<?php echo e($projet->libelle); ?>"</span></p>
        <div class="table-responsive p-5">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                      <tr>
                          <th>Num</th>
                          <th>Titre</th>
                          <th>Fichiers</th>
                          <th class="">Type Fichier</th>
                          <th>Date postée </th>
                          <th>Options</th>
                      </tr>
                  </thead>
                  <tfoot>
                      <tr>
                          <th>Num</th>
                          <th>Titre</th>
                          <th>Fichiers</th>
                          <th class="">Type Fichier</th>
                          <th>Date postée </th>
                          <th>Options</th>
                      </tr>
                    
                  </tfoot>
                  <tbody>
                    <?php ($nombre=0); ?>
                    <?php $__currentLoopData = $projet->fichier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fichier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e(++$nombre); ?></td>
                      <td><?php echo e($fichier->title); ?></td>
                      <td class="d-flex text-center  justify-content-center align-items-center">
                        <?php if($fichier->type == 'Image') { ?>
                            <a href="<?php echo e(asset($fichier->file_path)); ?>" title="Ouvrir l'image " target="_blank">
                                <img src="<?php echo e(asset($fichier->file_path)); ?>" width="100px" class="img-fluid" alt="image_<?php echo e($fichier->nom); ?>">
                            </a>
                        <?php } ?>
                        <?php if ($fichier->type == 'Video'): ?>
                            <video  preload='auto' controls width="300" height="120" >
                            <source src="<?php echo e(asset($fichier->file_path)); ?>" type="video/mp4">
                            <source src="<?php echo e(asset($fichier->file_path)); ?>" type="video/mpeg">
                            <source src="<?php echo e(asset($fichier->file_path)); ?>" type="video/avi">
                            <source src="<?php echo e(asset($fichier->file_path)); ?>" type="video/3gp">
                            </video>
                        <?php endif ?>
                                
                        <?php if ($fichier->type == 'Fichier'): ?>
                                <a href="<?php echo e(asset($fichier->file_path)); ?>" title="Ouvrir le document" target="_blank"><img src="<?php echo e(asset('img/Files.png')); ?>" width="100px" class="img-fluid"  ></a>
                        <?php endif ?>
                      </td>
                    <td><?php echo e($fichier->type); ?></td>
                      <td><?php echo e($fichier->created_at); ?></td>
                      <td class="text-center">
                         
                        <form onclick="return confirm('Etes-vous sure de vouloir supprimer definiment ce fichier ?')" action="<?php echo e(route('projet.fichiers.destroy',[$projet, $fichier])); ?>" method="POST" style="display: inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class=" btn btn-sm btn-circle btn-danger my-4"><i class="fas fa-trash"></i></button type="submit">
                        </form>
                          
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
        </div>   
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/fichiers/create.blade.php ENDPATH**/ ?>