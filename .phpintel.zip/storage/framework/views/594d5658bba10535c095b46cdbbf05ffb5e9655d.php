<?php $__env->startSection('content'); ?>

<style type="">
 .size2{
   font-size: 1.2em
 }
 .size3{
   font-size: 1.3em
 }
 .size6{
   font-size: 1.6em
 }
</style>
</header>
<div class="view mt-0 pt-0">
 <img src="assets/img/Ban_blog.jpg" class="img-fluid w-100">
 <div class="mask  waves-effect waves-light justify-content-center d-flex align-items-center">
    <div class="row ">
        <div class="col-md-12 text-center">
            <h3 class="white-text h3-responsive font-weight-bold text-uppercase text-center">
                Univers Agro 237 vous offre la possibilité de vous exprimer, 
                de <br> communiquer et de mettre  en valeur votre<br> production à travers un blog
            </h3>
        </div>
    </div>
</div>
</div>
<section class="mt-">
 <div class="container">
   <p class="font-weight-bold my-5 mx-5 text-center wow fadeIn Up  size6">REJOIGNEZ NOTRE COMMUNAUTE D'AGRICULTURE ET D'ELEVEURS EN CREANT LE VOTRE DES AUJOURD'HUI</p>
   <center>
     <a href="<?php echo e(route('blogs.create')); ?>"> <button class="btn btn-orange"><i class="fas fa-arrow-right"></i> Créer un blog gratuitement</button></a>
   </center>

<div class="row" syle="margin-top: 123px">
  <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-lg-4 col-md-6 wow fadeIn Up">
    <div class=" testimonial-card grey lighten-3">
      <div class="card-up white lighten-1"></div>
      <div class="avatar mx-auto white">
        <img src="https://mdbootstrap.com/img/Photos/Avatars/img%20%2810%29.jpg" class="rounded-circle" alt="woman avatar">
      </div>
      <div class="card-body ">
        <h4 class="card-title" style="height: 50px "><?php echo e($item->titre); ?></h4>
        <hr>
        <p style="height: 110px; "><i class="fas fa-quote-left"></i> 
          <?php
            $description=$item->description;
          if (strlen($description  )>170) 
              {
              $description=substr($description, 0, 170);
              $dernier_mot=strrpos($description," ");
              $description=substr($description,0,$dernier_mot)."...";
              }
          ?> 
              <?php echo e($description); ?>

               <i class="fas fa-quote-right"></i>
        </p>
      </div>
    </div>
      <div class="text-center my-2">
       <a href="<?php echo e(route('home_blog', $item)); ?>"><button class="btn" style="background-color: saddlebrown"><i class="fas fa-arrow-right"></i> Visiter le blog</button></a>
      </div>
  </div> 
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutUser', ['page' => 'Blogs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/pages/blog.blade.php ENDPATH**/ ?>