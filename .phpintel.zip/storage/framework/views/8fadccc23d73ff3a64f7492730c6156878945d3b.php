<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <?php if(count($annonces)==0): ?>
        <p class="text-warning text-center font-weight-bold my-3">
            Aucune annonce disponible !!
        </p>
    <?php endif; ?>
    <div class="col-md-12 col-lg-12 mb-2">
         <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-lg-12">
            <div class="row">
                <div class="col-md-4 col-lg-4 align-items-center d-flex justify-content-center">
                    <?php if($annonce->typ_fichier == 'Image') { ?>
                        <a href="<?php echo e(asset($annonce->fichier)); ?>" target="_blank">
                            <img src="<?php echo e(asset($annonce->fichier_path)); ?>" class="img-fluid  d-block w-100" alt="<?=$annonce->fichier?>">
                        </a>
                      <?php } ?>
                      <?php if ($annonce->typ_fichier == 'Video'): ?>
                        <video  preload='auto' controls width="300" height="120" >
                          <source src="<?php echo e(asset($annonce->fichier_path)); ?>" type="video/mp4">
                          <source src="<?php echo e(asset($annonce->fichier_path)); ?>" type="video/mpeg">
                          <source src="<?php echo e(asset($annonce->fichier_path)); ?>" type="video/avi">
                          <source src="<?php echo e(asset($annonce->fichier_path)); ?>" type="video/3gp">
                        </video>
                      <?php endif ?>
    
                      <?php if ($annonce->typ_fichier == 'Fichier'): ?>
                            <a href="<?php echo e(asset($annonce->fichier_path)); ?>" target="_blank"><img src="img/Files.png" class="w-50 img-fluid"></a>
                      <?php endif ?>
                    
                </div>
                <div class="col-md-8 col-lg-8 text-left p-2">
                <h3 class="grey-text  font-weight-bold mb-2"><?php echo e($annonce->titre); ?></h3>
                    <hr class=" mb-2 grey">
                    <p class=" text-muted h5 text-justify">
                        <?php echo e($annonce->contenu); ?>

                    </p>
                    <?php if($annonce->type_announce==1): ?>
                        <p class=" black-text h5 mt-3"><span class="font-weight-bold"><u>Localisation</u>:</span> <?php echo e($annonce->localisation); ?> </p>
                        <p class=" black-text h5"><span class="font-weight-bold"><u>Superficie</u>:</span> <?php echo e($annonce->superficie); ?> </p>
                        <p class=" black-text h5"><span class="font-weight-bold"><u>Prix</u>:</span> <?php echo e($annonce->price); ?> FCFA</p>
                    <?php endif; ?>
                    <?php if($annonce->type_announce==0): ?>
                      <?php if($annonce->source): ?>
                          <p class=" black-text text-left"><span class="font-weight-bold blue-text">Source: </span> <?php echo e($annonce->source); ?> </p>
                      <?php endif; ?> 
                      <?php if($annonce->editeur): ?>
                          <p class=" black-text float-right"><span class="font-weight-bold blue-text">Editeur: </span> <?php echo e($annonce->editeur); ?> </p><br>
                      <?php endif; ?>
                       <?php endif; ?>
                    <p class="text-right text-muted mt-4 font-weight-bold"><span class="black-text"> Posté le:</span><?php echo e($annonce->created_at->format('d M Y à H:m:s')); ?></p>
                </div>  
            </div>
        </div>
        <hr class=" mb-4"  style="height: 1px;   background-color: rgb(0,166,80);"> <br>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutBlog', ['page' => 'Blogs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/pages/blogs/annonces.blade.php ENDPATH**/ ?>