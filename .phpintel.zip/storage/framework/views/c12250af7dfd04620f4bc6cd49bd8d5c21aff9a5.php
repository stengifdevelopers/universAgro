                    <?php echo csrf_field(); ?>
                    <input hidden class="form-control form-control-md <?php if ($errors->has('pro_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pro_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="pro_id"
                    type="text"  value="<?php echo e($projet->id); ?> ">
                        
                   <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="title">Titre du Fichier</label>
                            <input id="title" class="form-control form-control-md <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="title"
                            type="text" value="<?php echo e(isset ($emploi) ?  $emploi->lieu : old('title')); ?> ">
                            <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class=" col-lg-6">
                      <div class="form-group">
                        <label for="tof" class="h6">Fichier</label><br>
                        <input type="file" name="nom"   value="<?php echo e(old('nom')); ?>" id="tof" class="text-center center-block file-upload form-control">
                        <?php if($errors->has('nom')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('nom')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </div>
                    </div>
                   </div>
                   
                    
                   
<?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/fichiers/form.blade.php ENDPATH**/ ?>