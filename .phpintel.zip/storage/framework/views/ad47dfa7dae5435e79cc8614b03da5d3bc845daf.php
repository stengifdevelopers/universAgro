<?php $__env->startSection('content'); ?>
<div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="d-block w-100 img-fluid" src="<?php echo e(asset('img\utilities\Ban_projets.jpg')); ?>"
          alt="First slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100 img-fluid" src="<?php echo e(asset('img\utilities\Ban_projets.jpg')); ?>"
          alt="Second slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100 img-fluid" src="<?php echo e(asset('img\utilities\Ban_projets.jpg')); ?>"
          alt="Third slide">
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
</div>
<section class="mt-5">
    <div class="container">
      <div class="row">
      <?php $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 mb-3 wow fadeIn">
         <div class="view overlay d-flex align-items-center justify-content-center">
            <img src="<?php echo e(asset($item->image_path )); ?>"  class="w-100 img-fluid" style="height: 35vh">
           <a>
            <div class="mask rgba-white-slight"></div>
          </a>
         </div>
         <hr class="bg-agro-orange hr-height">
          <p class="text-justify font-weight-bold text-black-50 h4" style="height: 95px;" >
            <?php echo e($item->libelle); ?>

          </p>
          <hr class="bg-agro-orange hr-height">
          <p class="text-justify mb-3" style="font-size: 1.2em; height: 138px;">
            <?php echo e($item->description); ?>

          </p>
          <p class="mt-3 text-right green-text font-weight-bold"><i class="far fa-calendar-alt"></i> <?php echo e($item->created_at->format('d M Y à H:m:s')); ?></p>
          <div class="text-center">
             <a href="<?php echo e(route('show', $item)); ?>"><button class="btn btn-sm btn-amber "><i class="fas fa-arrow-right"></i> <span class="font-weight-bold">Afficher</span></button></a>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutUser', ['page' => 'Projects'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/pages/projets/index.blade.php ENDPATH**/ ?>