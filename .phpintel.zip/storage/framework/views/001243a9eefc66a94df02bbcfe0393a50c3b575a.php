<?php echo csrf_field(); ?>
<div class="form-group">
<label for="nom">Nom de l'article</label>
<input id="nom" class="form-control form-control-md <?php if ($errors->has('nom')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nom'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nom"
type="text" placeholder="Insérer un nom" value="<?php echo e(isset ($article) ?  $article->nom : old('nom')); ?> ">
<?php if ($errors->has('nom')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nom'); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>
<div class="form-group">
   <label for="exampleFormControlTextarea3">Description de l'article</label>
   <textarea name="description" class="form-control text-justify <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="exampleFormControlTextarea3" placeholder="Inserer du texte ici"  rows="7"><?php echo isset ($article) ?  $article->description : old('description'); ?></textarea>
   <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
   <div class="invalid-feedback">
       <?php echo e($message); ?>

   </div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>


<div class="row">
        <div class="col-lg-3">
         <div class="form-group">
            <label for="prix">Prix de l'article</label>
            <input id="prix" class="form-control form-control-md <?php if ($errors->has('prix')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prix'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="prix"
            type="text"  value="<?php echo e(isset ($article) ? $article->prix : old('prix')); ?> ">
            <?php if ($errors->has('prix')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prix'); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
         </div>
        </div>
        <div class="col-lg-3">
          <div class="form-group">
              <label for="prixRabais">Prix de rabais de l'article</label>
              <input id="prixRabais" class="form-control form-control-md <?php if ($errors->has('prixRabais')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prixRabais'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="prixRabais"
              type="text" value="<?php echo e(isset ($article) ?  $article->prixRabais : (old('prixRabais') ?? 0)); ?> ">
              <?php if ($errors->has('prixRabais')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prixRabais'); ?>
                  <div class="invalid-feedback">
                      <?php echo e($message); ?>

                  </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="form-group">
              <label for="pourcentRed">Pourcentage de reduction</label>
              <input id="pourcentRed" class="form-control form-control-md <?php if ($errors->has('pourcentRed')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pourcentRed'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="pourcentRed"
              type="text"  value="<?php echo e(isset ($article) ?  $article->pourcentRed : (old('pourcentRed') ?? 0)); ?> ">
              <?php if ($errors->has('pourcentRed')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pourcentRed'); ?>
                  <div class="invalid-feedback">
                      <?php echo e($message); ?>

                  </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="form-group">
              <label for="quantite">Quantité</label>
              <input id="quantite" class="form-control form-control-md <?php if ($errors->has('quantite')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('quantite'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="quantite"
              type="numeric"  value="<?php echo e(isset ($article) ?  $article->quantite : (old('quantite') ?? 0)); ?> ">
              <?php if ($errors->has('quantite')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('quantite'); ?>
                  <div class="invalid-feedback">
                      <?php echo e($message); ?>

                  </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
        </div>
      </div>
      <label for="">Fichier Image</label>
      <div class="input-group mb-3">
        
        <div class="custom-fil">
            <input type="file" class="custom-file-inpu <?php if ($errors->has('fichier')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fichier'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="fichier" id="profile-img" value="<?php echo e(isset ($article) ?  $article->fichier : (old('fichier'))); ?> " aria-describedby="">
            
        </div>
        <?php if ($errors->has('fichier')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fichier'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
       </div>
       <div class="form-group">
        <label for="" class="mt-3">Nom de la catégorie </label>
        <select name="cat_id" id="" class="custom-select  <?php if ($errors->has('cat_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cat_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
            <option disabled selected>Choisir une catégorie...</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($categorie->id); ?>" <?php echo e(isset ($article) ? ($article->categories->id == $categorie->id ? 'selected' : ''):''); ?>  ><?php echo e($categorie->nom); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php if ($errors->has('cat_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cat_id'); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
     </div>


     

     <img src="" id="profile-img-tag" width="200px" />



     <script type="text/javascript">

         function readURL(input) {

             if (input.files && input.files[0]) {

                 var reader = new FileReader();



                 reader.onload = function (e) {

                     $('#profile-img-tag').attr('src', e.target.result);
                 }
                 reader.readAsDataURL(input.files[0]);
             }
         }

         $("#profile-img").change(function(){

             readURL(this);

         });

     </script>
<?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/articles/form.blade.php ENDPATH**/ ?>