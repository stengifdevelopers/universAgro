<?php $__env->startSection('content'); ?>


 <div class="mx-5 mt-5">
   <div class="row">
     <div class="col-lg-8">
        
         <?php 
         
            //  $idurl =1 ;
            //  $nbv= $_GET['vue'] +1;
             
                         
             $today = date("Y-m-d");
             
             $diff = abs(strtotime($emplois->date_fin) - strtotime($today));
             $years = floor($diff / (365*60*60*24));
             $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
             $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

         
         
         ?>
         <?php if ( $today > $emplois->date_fin): ?>
            <p class="alert-danger p-2 rounded-top text-center font-weight-bold" style="font-size: 1.2em">Cette offre est achevée</p>
         <?php else: ?>
            <p class="alert-danger p-2 rounded-top text-center font-weight-bold" style="font-size: 1.2em"> Cette offre s'achève dans <?= $months. " ". "mois". " ". $days ?> jours !!! </p>
         <?php endif ?>
       <div class="widget dark">
         <p class="font-weight-bold  widget-title line-bottom black-text" title="Offre d'emploi" style="font-size: 1.3em"><?php echo e($emplois->titre); ?>  
         <span class="font-weight-bold  float-right black-text" style="font-size: 0.9em"> <span class="label btn-warning px-2 rounded" title="Type de contrat"><?php echo e($emplois->type_contrat); ?></span></span><br>
          <span style="font-size: 0.7em">&nbsp;&nbsp;<i class="fas fa-business-time"></i> Posté le:  <?php echo e($emplois->created_at->format('d M Y à H:m:s')); ?></span>
         </p>

       </div>
       <table class="table table-borderless table_style">
         <tbody >
             <tr>
                 <!-- <td>Posté : 18-06-2019</td> -->
                 <td><i class="fas fa-store-alt"></i> Société/Structure : <span class="font-weight-bold"><?php echo e($emplois->society); ?></span></td>
             </tr>
             <tr>
                 <td><i class="fas fa-map-marked-alt"></i> Lieu : <?php echo e($emplois->lieu); ?></td>
                 <td><i class="far fa-eye"></i> Vues :<?php echo e($emplois->view); ?></td>
             </tr>
             <tr>
                 <td><i class="fas fa-book-reader"></i> Type de contrat :  
                     <?php 
                                  if ($emplois->type_contrat=="CDD") {
                                       
                                       echo " Contrat à durée Déterminée (CDD)";

                                  } elseif ($emplois->type_contrat=="CDI") {

                                     echo " Contrat à Durée Indéterminée (CDI)";

                                  } elseif ($emplois->type_contrat=="Stage") {

                                      echo " Contrat de Stage";
                                  }else {

                                     echo " Non déterminée";
                                  }

                              ?>  </td>
                 <td><i class="far fa-envelope"></i> Postuler via le mail :<span class="yellow px-1 rounded font-weight-bold"><?php echo e($emplois->email_post); ?></span></td>
                 
             </tr>
                                 <tr>
                     <td><i class="fas fa-stopwatch"></i> Date expiration : <span class="font-weight-bold grey-text"><?php echo e($emplois->date_fin->format('d M Y')); ?></span></td>
                 </tr>
         </tbody>
     </table>


      <hr style="height:4px; background-color:  rgba(0, 188, 212, 0.1)">
      
     <h4 class="text-center mt-3 mb-2 font-weight-bold"><?php echo e($emplois->titre); ?></h4>
    <p class="text-justify" style="font-size: 1.2em">
        <?php echo e($emplois->description); ?>

    </p>
    <p class="text-justify">
      <span class="font-weight-bold"> Pièces à fournir:</span> <br> <?php echo e($emplois->documents); ?>

    </p>

<p class="font-weight-bold mt-2"><span>Autres Offres</span><span class="float-right"><a href="<?php echo e(route('offers')); ?>">Consulter la liste</a></span></p>
     <hr class="grey" style="height:1px; margin-top: -12px" >
     <?php if (count($last)==0) { ?> 
        <p class="text-center mt-5 font-weight-bold text-warning">Aucune offre disponible !!</p> 
     <?php } ?> 
     <table class="table table-hover table-responsive w-100">
        <tbody>
            <?php $__currentLoopData = $last; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
                 <td  class="text-center text-wrap" style="width: 10% ;">
                    <?php if ($item->image_path): ?>
                    <div class="align-items-center text-center d-flex justify-content-center">
                      <a href="<?php echo e($item->image_path); ?>" target="_blank"><img src="<?php echo e(asset($item->image_path)); ?>" class="w-75 img-fluid" alt="<?php echo e($item->image); ?>"></a>
                    </div>
                    <?php else: ?>
                        <p class="text-center">
                            <img src="https://img.icons8.com/fluent/48/000000/find-matching-job.png"/>
                        </p>
                    <?php endif ?><br>
                     <span class="text-center"><?php echo e($item->created_at->format('d M Y')); ?></span>
                  </td>
                <td class="">
                <a href="<?php echo e(route('details_emplois', $item)); ?>"> <strong class="grey-tex font-weight-bold" style="font-size: 1.3em"><?php echo e($item->titre); ?></strong>
                    <p class="text-muted mt-2">
                        <?php echo e($item->description); ?>

                    </p>
                    <p class="mt-4"><i class="fas fa-at"></i> Email: <?php echo e($item->email_post); ?> &nbsp;&nbsp;&nbsp;<i class="green-text fas fa-search-location"></i> <?php echo e($item->lieu); ?></p></a>
                </td>
                <td class="text-center">
                  <a href="<?php echo e(route('details_emplois', $item)); ?>">
                        <?php if ($item->type_contrat=="CDD"){ ?>
                            <span class="label btn-success px-2 rounded">CDD</span>            
                        <?php 
                        }
                        elseif($item->type_contrat=="CDI"){ ?>
                            <span class="label btn-primary px-2 rounded">CDI</span>
                        <?php
                        }
                        elseif($item->type_contrat=="Stage"){ ?>
                            <span class="label btn-warning px-2 rounded">Stage</span> 
                        <?php 
                        } 
                        else {  ?>
                            <span class="label btn-danger px-2 rounded">Autre</span>
                        <?php } ?>
                      <p class="mt-3"> Fin de l'offre: <?php echo e($item->date_fin->format('d M Y')); ?></p>
                  </a>
                </td>
             </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
     <hr>

   </div>

     <div class="col-lg-4 mt-5 text-center">
       <div class="mt-4 white-text">.</div>
       <div class="widget dark">
         <h1 class="widget-title line-bottom black-text" style="font-size:1.3em;">Notes d'Informations</h1>
         <div id="carousel-example-multi" class="carousel slide carousel-multi-item my-3" data-ride="carousel">
                 <div class="carousel-inner " role="listbox">

                     <div class="carousel-item active ">
                         <div class="col-lg-12 col-md-6">
                             <div class="card text-center">
                                 <img class="card-img-top rounded" height="500px" src="../public/img/images/pub5.jpg"  alt="Pub 1">

                             </div>
                         </div>
                     </div>
                     <div class="carousel-item">
                         <div class="col-lg-12 col-md-6">
                             <div class="card  text-center">
                                 <img class="card-img-top rounded" height="500px" src="../public/img/images/pub6.jpg" alt="Pub 2">

                             </div>
                         </div>
                     </div>
                     <div class="carousel-item">
                         <div class="col-lg-12 col-md-6">
                             <div class="card  text-center">
                                 <img class="card-img-top rounded" height="500px " src="../public/img/images/pub7.jpg" alt="Pub 3">

                             </div>
                         </div>
                     </div>
                 </div>

             </div>

         <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FMy-business-story-413230905690197%2F&tabs=timeline%2C%20events%2C%20messages&width=300&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId&data-adapt-container-width"  height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>


         <div class="fb-like" data-href="https://www.facebook.com/My-business-story-413230905690197/" data-width="250" data-layout="standard" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div>

        

        <div class="fb-comments" data-href="https://www.facebook.com/My-business-story-413230905690197" data-height="111" data-numposts="5"></div>

       </div>
     </div>
   </div>
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutUser', ['page' => 'Offres'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/pages/offers/show.blade.php ENDPATH**/ ?>