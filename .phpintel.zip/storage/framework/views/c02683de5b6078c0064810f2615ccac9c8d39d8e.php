<?php echo csrf_field(); ?>
  <div class="form-group row">
    <div class="col-sm-6 mb-3 mb-sm-0">
        <label for="nom" class="col-form-label text-md-right"><?php echo e(__('Nom')); ?></label>
        <input id="nom" type="text" class="form-control form-control-user <?php if ($errors->has('nom')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nom'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nom" value="<?php echo e(isset ($user) ? $user->name : old('nom')); ?>"  autocomplete="nom" autofocus>
        <?php if ($errors->has('nom')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nom'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
    <div class="col-sm-6">
        <label for="pseudo" class="col-form-label text-md-right"><?php echo e(__('Pseudo')); ?></label>
        <input id="pseudo" type="text" class="form-control form-control-user <?php if ($errors->has('pseudo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pseudo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="pseudo" value="<?php echo e(isset ($user) ? $user->pseudo : old('pseudo')); ?> "  autocomplete="pseudo" autofocus>
        <?php if ($errors->has('pseudo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pseudo'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
  </div>
  <div class="form-group row">
    <div class="col-sm-6 mb-3 mb-sm-0">
        <label for="email" class="col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
        <input id="email" type="email" class="form-control form-control-user <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(isset ($user) ? $user->email : old('email')); ?>" autocomplete="email" autofocus>
        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
    <div class="col-sm-6">
        <label for="fonction" class="col-form-label text-md-right"><?php echo e(__('Profession')); ?></label>
        <input id="fonction" type="text" class="form-control form-control-user <?php if ($errors->has('fonction')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fonction'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="fonction" value="<?php echo e(isset ($user) ? $user->fonction : old('fonction')); ?>"  autocomplete="fonction" autofocus>
        <?php if ($errors->has('fonction')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fonction'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
  </div>
  <div class="form-group row">
    <div class="col-sm-6 mb-1 mb-sm-0">
        <label for="" class="mt-3">Rôle de l'utilisateur </label>
        <select name="role" id="" class="custom-select custom-select-user  <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
            <option disabled selected>Choisir un rôle ...</option>
            <option value="0" <?php echo e(isset($user) && $user->role=="0" ? 'selected' : ''); ?>>Utilisateur</option>
            <option value="1" <?php echo e(isset($user) && $user->role=="1" ? 'selected' : ''); ?>>Administrateur</option>
            <option value="2" <?php echo e(isset($user) && $user->role=="2" ? 'selected' : ''); ?>>Editeur</option>
            <option value="4" <?php echo e(isset($user) && $user->role=="4" ? 'selected' : ''); ?>>Super Admin</option>

        </select>
        <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
    <div class="col-sm-6">
    </div>
  </div>
  <hr>
<?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/users/form.blade.php ENDPATH**/ ?>