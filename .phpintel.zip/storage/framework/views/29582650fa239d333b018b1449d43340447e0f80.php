<?php $__env->startSection('content'); ?>

    <div class="container">
            <div class="row justify-content-center">
              <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="card o-hidden border-0 shadow-lg my-5">
                  <div class="card-body p-5">
                    <!-- Nested Row within Card Body -->
                    <h1>Formulaire de modification d'une annonce</h1>
                    <div class="text-right">
                        <a href="<?php echo e(route('annonces.index')); ?>"><button class=" btn btn-sm btn-primary">Liste des annonces</button></a>
                    </div>
                    <form action="<?php echo e(route('annonces.update', $annonce->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('PATCH'); ?>

                        <?php echo $__env->make('Admin.annonces.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="text-center mt-5">
                            <button class="btn btn-sm btn-success">
                                Modifier
                            </button>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/annonces/edit.blade.php ENDPATH**/ ?>