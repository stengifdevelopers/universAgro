<?php $__env->startSection('content'); ?>


<style>
 body{
    background: -webkit-linear-gradient(left, #3931af, #00c6ff);
}
.emp-profile{
    padding: 3%;
    margin-top: 3%;
    margin-bottom: 3%;
    border-radius: 0.5rem;
    background: #fff;
}
.profile-img{
    text-align: center;
}
.profile-img img{
    width: 70%;
    height: 100%;
}
.profile-img .file {
    position: relative;
    overflow: hidden;
    margin-top: -20%;
    width: 70%;
    border: none;
    border-radius: 0;
    font-size: 15px;
    background: #212529b8;
}
.profile-img .file input {
    position: absolute;
    opacity: 0;
    right: 0;
    top: 0;
}
.profile-head h5{
    color: #333;
}
.profile-head h6{
    color: #0062cc;
}
.profile-edit-btn{
    border: none;
    border-radius: 1.5rem;
    width: 70%;
    padding: 2%;
    font-weight: 600;
    color: #6c757d;
    cursor: pointer;
}
.proile-rating{
    font-size: 12px;
    color: #818182;
    margin-top: 5%;
}
.proile-rating span{
    color: #495057;
    font-size: 15px;
    font-weight: 600;
}
.profile-head .nav-tabs{
    margin-bottom:5%;
}
.profile-head .nav-tabs .nav-link{
    font-weight:600;
    border: none;
}
.profile-head .nav-tabs .nav-link.active{
    border: none;
    border-bottom:2px solid #0062cc;
}
.profile-work{
    padding: 14%;
    margin-top: -15%;
}
.profile-work p{
    font-size: 12px;
    color: #818182;
    font-weight: 600;
    margin-top: 10%;
}
.profile-work a{
    text-decoration: none;
    color: #495057;
    font-weight: 600;
    font-size: 14px;
}
.profile-work ul{
    list-style: none;
}
.profile-tab label{
    font-weight: 600;
}
.profile-tab p{
    font-weight: 600;
    color: #0062cc;
}
</style>
<div class="container-fluid">
    <div class="container emp-profile">
        <form method="post">
            <div class="row">
                <div class="col-md-4">
                    <div class="profile-img">
                        <?php if ($profile->profile_path): ?>
                            <a href="<?php echo e($profile->profile_path); ?>"><img src="<?php echo e(asset($profile->profile_path)); ?>" width="100px" class="img-fluid"  alt="<?php echo e($profile->image); ?>"></a>
                        <?php else: ?>
                            <a href=""><img src="<?php echo e(asset('img/utilities/default.png')); ?>" width="100px" class="img-fluid"  alt="default.png"></a>
                        <?php endif ?>
                        <div class="file btn btn-lg btn-primary">
                            Change Photo
                            <input type="file" name="file"/>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="profile-head">
                                <h5>
                                    <?php echo e($user->name); ?>

                                </h5>
                                <h6>
                                    <?php echo e($user->fonction); ?>

                                </h6>
                                <p class="proile-rating">RANKINGS : <span>8/10</span></p>
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">A propos</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Description</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 text-center">
                    <a href="<?php echo e(route('pwdedit.edit', Auth::user()->id)); ?>" class="btn btn-outline-warning btn-sm mb-2">
                        <i class="fas fa-key"></i> Edit Pswd
                </a>
                <a href="<?php echo e(route('profile.edit', $profile->id)); ?>" class="btn btn-outline-success btn-sm mb-2">
                    <i class="fas fa-users-cog"></i> Edit Profile
            </a>
                
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="profile-work">
                        <p>Mes Liens</p>
                        <div class="mb-2">
                            <span  class="btn btn-sm btn-warning btn-circle white">
                                <i class="fas fa-globe"></i>
                            </span>
                            <a href="https://<?php echo e($profile->url); ?>" target="_blank">
                              <?php if($profile->url==""): ?>
                                <?php echo e('Aucne information'); ?>

                              <?php else: ?>
                                <?php echo e($profile->url); ?>

                              <?php endif; ?>

                            </a><br/>
                        </div>
                        <div class="mb-2">
                            <span  class="btn btn-sm btn-primary btn-circle white">
                                <i class="fab  fa-facebook-f"></i>
                            </span>
                            <a href="https://<?php echo e($profile->facebook); ?>" target="_blank">
                                <?php if($profile->facebook==""): ?>
                                <?php echo e('Aucne information'); ?>

                              <?php else: ?>
                                <?php echo e($profile->facebook); ?>

                              <?php endif; ?>

                            </a><br/>
                        </div>
                        <div class="mb-2">
                            <span  class="btn btn-sm btn-success btn-circle white">
                                <i class="fab fa-whatsapp"></i>
                            </span>
                            <a>
                             <?php if($profile->whatsapp==""): ?>
                                <?php echo e('Aucne information'); ?>

                              <?php else: ?>
                                <?php echo e($profile->whatsapp); ?>

                              <?php endif; ?>

                            </a><br/>
                        </div>

                        <p>Mes localisations:</p>

                        <a href="#">Région:
                            <?php if($profile->region==""): ?>
                                <?php echo e('Aucne information'); ?>

                              <?php else: ?>
                                <?php echo e($profile->region); ?>

                              <?php endif; ?>
                        </a><br/>
                        <a href="#">Département:
                            <?php if($profile->departement==""): ?>
                              <?php echo e('Aucne information'); ?>

                            <?php else: ?>
                              <?php echo e($profile->departement); ?>

                            <?php endif; ?>
                        </a><br/>
                        <a href="#">Ville:
                            <?php if($profile->ville==""): ?>
                                <?php echo e('Aucne information'); ?>

                            <?php else: ?>
                                <?php echo e($profile->ville); ?>

                            <?php endif; ?>
                        </a><br/>

                    </div>
                </div>
                <div class="col-md-8">
                    <div class="tab-content profile-tab" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>User Id</label>
                                        </div>
                                        <div class="col-md-6">
                                            <p><?php echo e($user->id); ?></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Pseudo</label>
                                        </div>
                                        <div class="col-md-6">
                                            <p><?php echo e($user->pseudo); ?></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Email</label>
                                        </div>
                                        <div class="col-md-6">
                                            <p><?php echo e($user->email); ?></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Phone</label>
                                        </div>
                                        <div class="col-md-6">
                                            <p>
                                                <?php if($profile->phone==""): ?>
                                                  <?php echo e('Vide'); ?>

                                                <?php else: ?>
                                                  <?php echo e($profile->phone); ?>

                                                <?php endif; ?>
                                             </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Profession</label>
                                        </div>
                                        <div class="col-md-6">
                                            <p><?php echo e($user->fonction); ?></p>
                                        </div>
                                    </div>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="col-lg-12">
                                <label>Your description</label><br/>
                                <p>
                                    <?php if($profile->phone==""): ?>
                                        <p class="text-center"><?php echo e('Aucne information'); ?></p>
                                    <?php else: ?>
                                        <?php echo e($profile->description); ?>

                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/profile/index.blade.php ENDPATH**/ ?>