<?php $__env->startSection('content'); ?>


<style>
  .decor{
      text-decoration: orangered;
  }
</style>
<div class="container bootstrap snippet">
    <div class="row">
    <div class="col-sm-10"><h4><a  href="<?php echo e(route('index')); ?>"><span class="decor">Home</span></a> / <a class="decor" href="<?php echo e(route('profile.index')); ?>">Profile</a> / <a class="decor" href="#">Edit Profile</a></h4></div>
    	<div class="col-sm-2"><a href="/users" class="pull-right"><img title="profile image" class="rounded-circle img-fluid" src="http://www.gravatar.com/avatar/28fd20ccec6865e2d5f0e1f4446eb7bf?s=100"></a></div>
    </div>
    <div class="row">
  		<div class="col-lg-3"><!--left col-->


      <div class="text-center">
        <?php if ($profile->profile_path): ?>
            <a href="<?php echo e($profile->profile_path); ?>"><img src="<?php echo e(asset($profile->profile_path)); ?>"  class="w-100  rounded-circle img-fluid img-thumbnail" style="height: 250px" alt="<?php echo e($profile->image); ?>"></a>
        <?php else: ?>
            <a href=""><img src="<?php echo e(asset('img/utilities/default.png')); ?>"  class="w-100  rounded-circle img-fluid img-thumbnail" style="height: 250px" alt="default.png"></a>
        <?php endif ?>
       
    </div>


          
        </div><!--/col-3-->
    	<div class="col-lg-9">
          <div class="tab-content">
            <div class="tab-pane active" id="home">
                  <form action="<?php echo e(route('profile.update', $profile->id)); ?>" method="POST" enctype="multipart/form-data" >
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-lg-6">
                          <div class="form-group">
                              <label for="first_name"><h5>Nom</h5></label>
                              <input type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(isset ($user) ? $user->name : old('name')); ?> " id="first_name"  title="enter your name if any.">
                              <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                          </div>
                      </div>
                      <div class="col-lg-6">
                          <div class="form-group">
                            <label for="last_name"><h5>Pseudo</h5></label>
                              <input type="text" name="pseudo" class="form-control <?php if ($errors->has('pseudo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pseudo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(isset ($user) ? $user->pseudo : old('pseudo')); ?> " name="pseudo" id="last_name" title="enter your pseudo if any.">
                              <?php if ($errors->has('pseudo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pseudo'); ?>
                              <div class="invalid-feedback">
                                  <?php echo e($message); ?>

                              </div>
                              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                      </div>
                      <div class="col-lg-6 mb-2">
                        <label for="phone" class="h5">Numéro télephone</label>
                        <div class="input-group input-group-seamless" data-children-count="1">
                            <div class="input-group-prepend">
                            <div class="input-group-text" data-children-count="0">
                                <i class="fas fa-phone-volume"></i>
                            </div>
                            </div>
                            <input type="number" value="<?php echo e(isset ($profile) ? $profile->phone : old('phone')); ?>" class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" name="phone" data-kwimpalastatus="alive" data-kwimpalaid="1582069334786-8">
                            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                             <div class="invalid-feedback">
                                <?php echo e($message); ?>

                             </div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                      </div>
                      <div class="col-lg-6 mb-2">
                        <label for="socialGoogle" class="h5">Adresse Email</label>
                        <div class="input-group input-group-seamless" data-children-count="1">
                          <div class="input-group-prepend">
                            <div class="input-group-text" data-children-count="0">
                              <i class="fab fa-google-plus-g"></i>
                            </div>
                          </div>
                          <input type="email" name="email" value="<?php echo e(isset ($user) ? $user->email : old('email')); ?>" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="socialGoogle" data-kwimpalastatus="alive" data-kwimpalaid="1582069334786-9">
                          <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                      </div>
                      <div class="col-lg-6">
                        <div class="form-group">
                            <label for="region"><h5>Région</h5></label>
                            <input type="text" value="<?php echo e(isset ($profile) ? $profile->region : old('region')); ?>" class="form-control" name="region" id="region"  title="enter your region if any.">
                            <?php if ($errors->has('region')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('region'); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                      </div>
                      <div class="col-lg-6">
                        <div class="form-group">
                            <label for="departement"><h5>Département</h5></label>
                            <input type="text" class="form-control" value="<?php echo e(isset ($profile) ? $profile->departement : old('departement')); ?>" name="departement" id="departement"  title="enter your subdivision if any.">
                            <?php if ($errors->has('departement')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('departement'); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                      </div>
                      <div class="form-group col-lg-6">
                        <label for="ville" class="h5">Ville</label>
                        <div class="input-group input-group-seamless" data-children-count="1">
                          <div class="input-group-prepend">
                            <div class="input-group-text" data-children-count="0">
                                <i class="fas fa-warehouse"></i>
                            </div>
                          </div>
                          <input type="text" value="<?php echo e(isset ($profile) ? $profile->ville : old('ville')); ?>" class="form-control" id="ville" name="ville" data-kwimpalastatus="alive" data-kwimpalaid="1582069334786-8">
                          <?php if ($errors->has('ville')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ville'); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                      </div>
                      <div class="form-group col-lg-6">
                        <label for="whatsapp" class="h5">Profession</label>
                        <div class="input-group input-group-seamless" data-children-count="1">
                          <div class="input-group-prepend">
                            <div class="input-group-text" data-children-count="0">
                                <i class="fas fa-briefcase"></i>
                            </div>
                          </div>
                          <input type="text" value="<?php echo e(isset ($user) ? $user->fonction : old('fonction')); ?>" name="fonction" class="form-control <?php if ($errors->has('fonction')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fonction'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="whatsapp" data-kwimpalastatus="alive" data-kwimpalaid="1582069334786-8">
                          <?php if ($errors->has('fonction')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fonction'); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                      </div>
                        <div class="form-group col-lg-6 ">
                          <label for="socialSlack" class="h5">Lien Facebook</label>
                          <div class="input-group input-group-seamless" data-children-count="1">
                            <div class="input-group-prepend">
                              <div class="input-group-text" data-children-count="0">
                                <i class="fab fa-facebook-f"></i>
                              </div>
                            </div>
                            <input type="text" name="facebook" value="<?php echo e(isset ($profile) ? $profile->facebook : old('facebook')); ?>" class="form-control <?php if ($errors->has('facebook')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('facebook'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="socialSlack" data-kwimpalastatus="alive" data-kwimpalaid="1582069334786-7">
                            <?php if ($errors->has('facebook')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('facebook'); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        </div>
                        <div class="form-group col-lg-6">
                          <label for="whatsapp" class="h5">Numéro WhatsApp</label>
                          <div class="input-group input-group-seamless" data-children-count="1">
                            <div class="input-group-prepend">
                              <div class="input-group-text" data-children-count="0">
                                <i class="fab fa-whatsapp"></i>
                              </div>
                            </div>
                            <input type="number" name="whatsapp" value="<?php echo e(isset ($profile) ? $profile->whatsapp : old('whatsapp')); ?>" class="form-control" id="whatsapp" data-kwimpalastatus="alive" data-kwimpalaid="1582069334786-8">
                            <?php if ($errors->has('whatsapp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('whatsapp'); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="whatsapp" class="h5">Lien du site web</label>
                            <div class="input-group input-group-seamless" data-children-count="1">
                                <div class="input-group-prepend">
                                <div class="input-group-text" data-children-count="0">
                                    <i class="fas fa-globe"></i>
                                </div>
                                </div>
                                <input type="text" name="url" value="<?php echo e(isset ($profile) ? $profile->url : old('url')); ?>" class="form-control <?php if ($errors->has('url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('url'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="whatsapp" data-kwimpalastatus="alive" data-kwimpalaid="1582069334786-9">
                                <?php if ($errors->has('url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('url'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="tof" class="h5">Photo de profil</label>
                            <input type="file" name="image" value="<?php echo e(isset ($profile) ? $profile->image : old('image')); ?>" id="tof" class="text-center center-block file-upload">
                        </div>
                        <div class="form-group col-lg-12">
                            <div class="form-group">
                                <label for="exampleFormControlTextarea3">Biographie</label>
                                <textarea name="description" class="form-control text-justify <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="exampleFormControlTextarea3" placeholder="Insérer une description" rows="7"><?php echo isset ($profile) ?  $profile->description : old('description'); ?></textarea>
                                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="col-lg-12 mb-5">
                            <div class="text-center mt-5">
                                <button class="btn btn-block btn-success">
                                    <i class="far fa-hdd"></i> Enregistrer
                                </button>
                            </div>
                      </div>
                    </div>
              	</form>
          </div><!--/tab-content-->
        </div><!--/col-9-->
    </div></div></div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/profile/edit.blade.php ENDPATH**/ ?>