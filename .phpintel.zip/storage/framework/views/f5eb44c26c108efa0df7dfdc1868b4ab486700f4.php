<?php $__env->startSection('content'); ?>
<div class="container">
    <p class="text-center mx-5 card p-3 rounded mt-5" style="font-family: Cairo, sans-serif; font-size: 1.7em">
      Vous êtes sur le point de vouloir créer un blog. Suivez toutes les procédures et tous les détails. Pour annuler, veuillez juste sortir de la page.
    </p>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 mt-5">
            <div class="card">
                <div class="card-header">
                    <div class="text-center">
                        <img src="<?php echo e(asset('img/Logo_header.png')); ?>" class="img-fluid rounded-circe">
                    </div>
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('blogs.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="custom-control custom-checkbox">
                                <input type="checkbox" name="choix[]" value="1"  class="custom-control-input" id="defaultUnchecked" onclick="myFunction()" <?php if(is_array(old('choix')) && in_array(1, old('choix'))): ?> checked <?php endif; ?>>
                                <label class="custom-control-label" for="defaultUnchecked">Je ne suis pas encore inscrit !</label>
                        </div>
                        <div id="text" style="visibility:hidden;height:0px">
                                <p><h2 class="orange text-center rounded">Informations personnelles</h2></p>
                                <div class="row">
                                        <div class="col-lg-6">
                                           <div class="form-group">
                                                <label for="nom" class="col-form-label text-md-right"><?php echo e(__('Nom')); ?></label>
                                                <input id="nom" type="text" class="form-control <?php if ($errors->has('nom')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nom'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nom" value="<?php echo e(old('nom')); ?>"  autocomplete="nom" autofocus>

                                                <?php if ($errors->has('nom')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nom'); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                                <div class="form-group">
                                                     <label for="pseudo" class="col-form-label text-md-right"><?php echo e(__('Pseudo')); ?></label>
                                                     <input id="pseudo" type="text" class="form-control <?php if ($errors->has('pseudo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pseudo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="pseudo" value="<?php echo e(old('pseudo')); ?>"  autocomplete="pseudo" autofocus>

                                                     <?php if ($errors->has('pseudo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pseudo'); ?>
                                                         <span class="invalid-feedback" role="alert">
                                                             <strong><?php echo e($message); ?></strong>
                                                         </span>
                                                     <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                 </div>
                                         </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-6">
                                          <div class="form-group">
                                               <label for="" class="col-form-label text-md-right"><?php echo e(__('Mot de passe')); ?></label>
                                               <input id="password" type="password" class="form-control <?php if ($errors->has('pwd')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pwd'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="pwd" value="<?php echo e(old('pwd')); ?>"  autocomplete="pwd" autofocus>
                                               <span id='icon' onclick="affichePassword()" class="fas fa-fw fa-eye field-icon"></span>
                                               <?php if ($errors->has('pwd')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pwd'); ?>
                                                   <span class="invalid-feedback" role="alert">
                                                       <strong><?php echo e($message); ?></strong>
                                                   </span>
                                               <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                           </div>
                                        </div>
                                        <div class="col-lg-6">
                                           <div class="form-group">
                                               <label for="pwd_confirmation" class="col-form-label text-md-right"><?php echo e(__('Confirmer mot de passe')); ?></label>
                                               <input id="pwd_confirmation" type="password" class="form-control <?php if ($errors->has('pwd_confirmation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pwd_confirmation'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  name="pwd_confirmation" autocomplete="pwd_confirmation" value="<?php echo e(old('pwd_confirmation')); ?>" autofocus>

                                               <?php if ($errors->has('pwd_confirmation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pwd_confirmation'); ?>
                                                   <span class="invalid-feedback" role="alert">
                                                       <strong><?php echo e($message); ?></strong>
                                                   </span>
                                               <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                           </div>
                                        </div>
                                      </div>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="email" class="col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
                                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>"  autocomplete="email" autofocus>
                                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                    <label for="fonction" class="col-form-label text-md-right"><?php echo e(__('Profession')); ?></label>
                                                    <input id="fonction" type="text" class="form-control <?php if ($errors->has('fonction')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fonction'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="fonction" value="<?php echo e(old('fonction')); ?>"  autocomplete="fonction" autofocus>

                                                    <?php if ($errors->has('fonction')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fonction'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                    </div>
                                    <p class="text-muted">Connectez-vous et completez votre profile une fois cette procedure terminée.</p>
                                    
                        </div>
                        <p><h2 class="orange text-center rounded">Informations du blog</h2></p>
                        <div class="form-group" id="emailFirst">
                                <label for="email2" class="col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
                                <input id="email2" type="email" class="form-control <?php if ($errors->has('email2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email2" value="<?php echo e(old('email2')); ?>"  autocomplete="email2" autofocus>

                                <?php if ($errors->has('email2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email2'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="titre" class="col-form-label text-md-right"><?php echo e(__('Donnez un titre a votre blog')); ?></label>
                            <input id="titre" type="text" class="form-control <?php if ($errors->has('titre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('titre'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="titre" value="<?php echo e(old('titre')); ?>"  autocomplete="titre" autofocus>

                            <?php if ($errors->has('titre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('titre'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <label for="sectAct" class="col-form-label text-md-right"><?php echo e(__('Secteur d\'activité')); ?></label>
                        <select id='sectAct' class="browser-default custom-select custom-select-md mb-3" name="secteur" <?php if ($errors->has('secteur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('secteur'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>>
                            <option disabled selected>Choisissez votre secteur d'activité</option>
                            <optgroup label="Agriculture">
                                <option value="Agriculture-Arboriculture">Arboriculture</option>
                                <option value="Agriculture-Cultures maraicheres">Cultures maraicheres</option>
                                <option value="Agriculture-Viticulture">Viticulture</option>
                            </optgroup>
                            <optgroup label="Elevage">
                                <option value="Elevage-Aulacodiculture">Aulacodiculture</option>
                                <option value="Elevage-Bovin">Bovin</option>
                                <option value="Elevage-Caprin">Caprin</option>
                                <option value="Elevage-Cuniculture">Cuniculture</option>
                                <option value="Elevage-Heliculture">Heliculture</option>
                                <option value="Elevage-Ovin">Ovin</option>
                                <option value="Elevage-Pisciculture">Pisciculture</option>
                                <option value="Elevage-Porciculture">Porciculture</option>
                            </optgroup>
                            <optgroup label="Agro-industries">
                              <option value="Transformation-Agroindustries">Industrie de transformation</option>
                            </optgroup>
                            <optgroup label="Autres">
                                <option value="Autres">Autres</option>
                            </optgroup>
                          </select>
                          <?php if ($errors->has('secteur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('secteur'); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                          <script>
                              // Material Select Initialization
                                $(document).ready(function() {
                                $('.mdb-select').materialSelect();
                                });
                            </script>

                        <div class="form-group">
                                <label for="exampleFormControlTextarea3">Decrivez en quelques mots votre blog</label>
                                <textarea name="description" class="form-control text-justify <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="exampleFormControlTextarea3" placeholder="Insérer une description" rows="7"><?php echo isset ($emploi) ?  $emploi->description : old('description'); ?></textarea>
                                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                <div class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="form-group mb-0">
                            <div class="text-center">
                                <button type="submit" class="btn btn-warning">
                                    <?php echo e(__('Créer')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/formulaires/create_blog.blade.php ENDPATH**/ ?>