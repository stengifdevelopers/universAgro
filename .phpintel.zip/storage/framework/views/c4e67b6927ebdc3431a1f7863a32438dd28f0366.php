<?php $__env->startSection('content'); ?>

<div class="view  ">
    <img  src="<?php echo e(asset('img/utilities/Ban_Anonces.jpg')); ?>" class="img-fluid  d-block w-100 mb-0" alt="zoom" >
    <div class="mask  waves-effect waves-light justify-content-center d-flex align-items-center">
        <div class="row ">
            <div class="col-md-12 text-center">
                <h2 class="white-text h2-responsive font-weight-bold " style="font-family: Matura MT Script Capitals, sans-serif">AGRICULTEUR DE DEMAIN</h2>
            </div>
            <div class="col-md-12">
                <hr class=" mb-4 "  style="height: 6px; width:200px;  background-color: white;">
            </div>
        </div>
    </div>
</div>

<div class="container">
 <p class="my-5 text-center h6 mx-5">Vous êtes intéréssés par une offre, 
     faites le choix sur celle qui vous convient et deposez vos documents à l'offreur  
 </p>

<?php if(count($emplois)==0): ?>
    <p class="text-warning text-center font-weight-bold my-3">
        Aucune offre disponible !!
    </p>
<?php endif; ?>
<table class="table table-hover table-responsive w-100">
<tbody>
    <?php $__currentLoopData = $emplois; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
         <td  class="text-center text-wrap" style="width: 10% ;">
            <?php if ($item->image_path): ?>
            <div class="align-items-center text-center d-flex justify-content-center">
              <a href="<?php echo e($item->image_path); ?>" target="_blank"><img src="<?php echo e(asset($item->image_path)); ?>" class="w-75 img-fluid" alt="<?php echo e($item->image); ?>"></a>
            </div>
            <?php else: ?>
                <p class="text-center">
                    <img src="https://img.icons8.com/fluent/48/000000/find-matching-job.png"/>
                </p>
            <?php endif ?><br>
             <span class="text-center"><?php echo e($item->created_at->format('d M Y')); ?></span>
          </td>
        <td class="">
        <a href="<?php echo e(route('details_emplois', $item)); ?>"> <strong class="grey-tex font-weight-bold" style="font-size: 1.3em"><?php echo e($item->titre); ?></strong>
            <p class="text-muted mt-2">
                <?php echo e($item->description); ?>

            </p>
            <p class="mt-4"><i class="fas fa-at"></i> Email: <?php echo e($item->email_post); ?> &nbsp;&nbsp;&nbsp;<i class="green-text fas fa-search-location"></i> <?php echo e($item->lieu); ?></p></a>
        </td>
        <td class="text-center">
          <a href="<?php echo e(route('details_emplois', $item)); ?>">
                <?php if ($item->type_contrat=="CDD"){ ?>
                    <span class="label btn-success px-2 rounded">CDD</span>            
                <?php 
                }
                elseif($item->type_contrat=="CDI"){ ?>
                    <span class="label btn-primary px-2 rounded">CDI</span>
                <?php
                }
                elseif($item->type_contrat=="Stage"){ ?>
                    <span class="label btn-warning px-2 rounded">Stage</span> 
                <?php 
                } 
                else {  ?>
                    <span class="label btn-danger px-2 rounded">Autre</span>
                <?php } ?>
              <p class="mt-3"> Fin de l'offre: <?php echo e($item->date_fin); ?></p>
          </a>
        </td>
     </tr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<hr class=" mb-4"  style="height: 1px;   background-color: rgb(0,166,80);">
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutUser', ['page' => 'Offres'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/pages/offers/index.blade.php ENDPATH**/ ?>