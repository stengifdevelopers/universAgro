<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Tables</h1>
    <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official DataTables documentation</a>.</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
      <div class="card-header py-3 align-items-center">
        <h2 class="m-0 font-weight-bold text-primary">Liste des articles (<?php echo e($articles->count()); ?>)

        </h2>
        <div class="text-right">
            <a href="<?php echo e(route('articles.create')); ?>" class="btn btn-primary btn-icon-split">
                <span class="icon text-white-50">
                    <i class="fas fa-plus"></i>
                </span>
                <span class="text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Ajouter Article</font></font></span>
            </a>
        </div>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr class="text-center">
                <th>Num</th>
                <th>Nom article</th>
                <th>Description</th>
                <th>Prix</th>
                <th>Rabais</th>
                <th>Categories</th>
                <th>Images</th>
                <th>Options</th>
              </tr>
            </thead>
            <tfoot>
              <tr class="text-center">
                <th>Num</th>
                <th>Nom articles</th>
                <th class="w-50">Descriptions</th>
                <th>Prix</th>
                <th>Rabais</th>
                <th>Categories</th>
                <th>Images</th>
                <th>Options</th>
              </tr>
            </tfoot>
            <tbody>
              <?php ($nombre=0); ?>
              <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e(++$nombre); ?></td>
                <td><?php echo e($article->nom); ?></td>
                <td><?php echo e(substr($article->description , 0, 145).'...'); ?></td>
                <td><?php echo e($article->prix); ?></td>
                <td><?php echo e($article->prixRabais); ?></td>
                <td><?php echo e($article->categories->nom); ?></td>
                <td class="d-flex  justify-content-center align-items-center">
                    <a href="<?php echo e(asset($article->fichier_path)); ?>" target="_blank"><img src="<?php echo e(asset($article->fichier_path)); ?>" class="w-50 img-fluid" alt="<?php echo e(asset($article->fichier)); ?>"></a>
                </td>
                <td class="text-center">
                    <a href="<?php echo e(route('articles.edit', $article->id)); ?>" class="btn btn-info btn-sm btn-circle">
                            <i class="fas fa-edit"></i>
                    </a>
                    

                    <form onclick="return confirm('Etes-vous sure de vouloir supprimer cet article')" action="<?php echo e(route('articles.destroy', $article)); ?>" method="POST" style="display: inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class=" btn btn-sm btn-circle btn-danger my-4"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/articles/index.blade.php ENDPATH**/ ?>