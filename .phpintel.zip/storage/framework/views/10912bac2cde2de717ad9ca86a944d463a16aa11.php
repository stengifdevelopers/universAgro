                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="libelle">Libelle du projet</label>
                        <input id="libelle" class="form-control form-control-md <?php if ($errors->has('libelle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('libelle'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="libelle"
                        type="text" placeholder="Insérer un libelle" value="<?php echo e(isset ($projet) ?  $projet->libelle : old('libelle')); ?> ">
                        <?php if ($errors->has('libelle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('libelle'); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    <div class="form-group">
                        <label for="exampleFormControlTextarea3">Description du projet</label>
                        <textarea name="description" class="form-control text-justify <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="exampleFormControlTextarea3" placeholder="Insérer une description" rows="7"><?php echo isset ($projet) ?  $projet->description : old('description'); ?></textarea>
                        <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="tof" class="h6">Photo</label><br>
                        <input type="file" accept="image/*" name="image"   value="<?php echo e(isset ($projet) ? $projet->image : old('image')); ?>" id="tof" class="text-center center-block file-upload form-control <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                        <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      </div>
<?php /**PATH C:\laragon\www\Agro237\resources\views/Admin/projets/form.blade.php ENDPATH**/ ?>